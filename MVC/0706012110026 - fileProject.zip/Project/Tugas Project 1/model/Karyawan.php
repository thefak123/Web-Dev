<?php
    class Karyawan{
        public $id;
        public $nama;
        public $jabatan;
        public $usia;
    }
?>