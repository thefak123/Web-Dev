<?php 
    class Office{
        public $id;
        public $officeName;
        public $address;
        public $city;
        public $phone;
    }
?>