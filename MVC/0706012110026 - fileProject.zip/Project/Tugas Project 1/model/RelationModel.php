<?php 
    class Relational{
        public $id;
        public $idKaryawan;
        public $idOffice;
    }
?>